/*
 * image_conversion.hpp
 *
 *  Created on: 21 Apr 2017
 *      Author: doyel
 */

#ifndef IMAGE_CONVERSION_HPP_
#define IMAGE_CONVERSION_HPP_

#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
#include <dirent.h>
#include <string>
#include <sstream>
#include <cstring>
#include <iostream>
#include <fstream>
#include <math.h>
#include <unistd.h>
#include <vector>
#include <random>
#include <map>
#include <iterator>

namespace dataset
{

class ImageDataset{

public:

	void CreateDatasetAlbatross(std::ostream& os);
	void CreateDatasetCheetah(std::ostream& os);
	void CreateDatasetGiraffe(std::ostream& os);
	void CreateDatasetOstrich(std::ostream& os);
	void CreateDatasetPenguin(std::ostream& os);
	void CreateDatasetTiger(std::ostream& os);
	void CreateDatasetZebra(std::ostream& os);

	void RandomShuffleData();
	void SaveinTrainFL(const std::string& filename);
	void SaveinTestFL(const std::string& filename);
	void SaveinValidationFL(const std::string& filename);
	bool SaveToStreamFL(std::ostream& os, int startSize, int endSize);

	void SaveinTrainPL(const std::string& filename);
	void SaveinTestPL(const std::string& filename);
	void SaveinValidationPL(const std::string& filename);
	void ExamplesShuffle();

	void SaveinTrainTS(const std::string& filename);
	void SaveinTestTS(const std::string& filename);
	void SaveinValidationTS(const std::string& filename);

protected:
	cv::Mat image;
	std::vector<double> image_pixels;
	std::map<std::string, int> dataset_all_patterns;
	std::vector<std::string> shuffle_temp;
	std::vector<std::string> lines;
	std::vector<cv::String> fn1;
	std::vector<cv::String> fn2;
	std::vector<cv::String> fn3;
};
}

#endif /* IMAGE_CONVERSION_HPP_ */
