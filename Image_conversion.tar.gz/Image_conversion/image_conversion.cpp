/*
 * image_conversion.cpp
 *
 *  Created on: 6 Jan 2017
 *      Author: soumali
 */


#define FULLYLABEL 1
#define PARTIALLABEL 0
#define TRANSSEP 0


#include "image_conversion.hpp"

#include <boost/lexical_cast.hpp>
#include <boost/regex.hpp>
#include <gflags/gflags.h>


DEFINE_string(trans_data_file, "TransData.dat", "Transductive File name where the patterns are stored");

DEFINE_string(train_examples_file, "TrainExamples.dat", "File name where the training examples are stored");
DEFINE_string(test_examples_file, "TestExamples.dat", "File name where the test examples are stored");
DEFINE_string(validation_examples_file, "ValidationExamples.dat", "File name where the validation examples are stored");

DEFINE_string(output_dir, ".", "Directory of output files");
DEFINE_string(input_dir, ".", "Directory of input files");

DEFINE_uint64(training_size,3325, "Size of the training input");
DEFINE_uint64(test_size,910, "Size of the test input");
DEFINE_uint64(validation_size,770, "Size of the validation input");
DEFINE_uint64(image_size,32, "Size of the images");


using namespace std;
using namespace cv;

int main(int argc, char** argv)
{
	google::ParseCommandLineFlags(&argc, &argv, true);
	dataset::ImageDataset ImgDt;

	string filename = FLAGS_input_dir + "/" + FLAGS_trans_data_file;
	ofstream os(filename.c_str());
	ImgDt.CreateDatasetAlbatross(os);
	ImgDt.CreateDatasetCheetah(os);
	ImgDt.CreateDatasetGiraffe(os);
	ImgDt.CreateDatasetOstrich(os);
	ImgDt.CreateDatasetPenguin(os);
	ImgDt.CreateDatasetTiger(os);
	ImgDt.CreateDatasetZebra(os);

#if FULLYLABEL == 1
	ImgDt.RandomShuffleData();
	ImgDt.SaveinTrainFL(FLAGS_output_dir + "/" + FLAGS_train_examples_file);
	ImgDt.SaveinTestFL(FLAGS_output_dir + "/" + FLAGS_test_examples_file);
	ImgDt.SaveinValidationFL(FLAGS_output_dir + "/" + FLAGS_validation_examples_file);
#endif

#if PARTIALLABEL == 1
	ImgDt.ExamplesShuffle();
	ImgDt.SaveinTrainPL(FLAGS_output_dir + "/" + FLAGS_train_examples_file);
	ImgDt.SaveinTestPL(FLAGS_output_dir + "/" + FLAGS_test_examples_file);
	ImgDt.SaveinValidationPL(FLAGS_output_dir + "/" + FLAGS_validation_examples_file);
#endif

#if TRANSSEP == 1
	ImgDt.SaveinTrainTS(FLAGS_output_dir + "/" + FLAGS_train_examples_file);
	ImgDt.SaveinTestTS(FLAGS_output_dir + "/" + FLAGS_test_examples_file);
	ImgDt.SaveinValidationTS(FLAGS_output_dir + "/" + FLAGS_validation_examples_file);
#endif

	return 0;
}
namespace dataset
{


void ImageDataset::CreateDatasetAlbatross(ostream& os)
{

	glob(FLAGS_input_dir + "/ImageNetSubset/albatross_train/*.jpg", fn1, true);

	cout << "Writing the albatross train pixels" << endl;

	os << "## Dataset.txt" << "\n";
	os << '\n';

	for (int i=0; i< fn1.size(); i++)
	{
		image = imread(fn1[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res1;
			res1 << i;
			string name_train = res1.str();
			string out_file = FLAGS_input_dir + "/albatross_formatted_train/"+name_train+".jpg";
			Mat copyImg_train;
			image.copyTo(copyImg_train);
			imwrite(out_file,copyImg_train);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "train" << i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			string out = boost:: lexical_cast<string>(i);
			dataset_all_patterns["train"+out] = i;
		}
	}

	cout << "Completed building the albatross train labels dataset" << endl;
	cout << "Completed writing the albatross train pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/albatross_test/*.jpg", fn2, true);

	cout << "Writing the albatross test pixels" << endl;

	for (int i=0; i < fn2.size(); i++)
	{
		image = imread(fn2[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res2;
			res2 << i;
			string name_test = res2.str();
			string out_file = FLAGS_input_dir + "/albatross_formatted_test/"+name_test+".jpg";
			Mat copyImg_test;
			image.copyTo(copyImg_test);
			imwrite(out_file,copyImg_test);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "test" << i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			string out = boost::lexical_cast<string>(i);
			dataset_all_patterns["test"+out] = i;
		}
	}

	cout << "Completed building the albatross test labels dataset" << endl;
	cout << "Completed writing the albatross test pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/albatross_validation/*.jpg", fn3, true);

	cout << "Writing the albatross validation pixels" << endl;

	for (int i=0;  i < fn3.size(); i++)
	{
		image = imread(fn3[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res3;
			res3 << i;
			string name_validation = res3.str();
			string out_file = FLAGS_input_dir + "/albatross_formatted_validation/"+name_validation+".jpg";
			Mat copyImg_validation;
			image.copyTo(copyImg_validation);
			imwrite(out_file,copyImg_validation);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "validation" << i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			string out = boost::lexical_cast<string>(i);
			dataset_all_patterns["validation"+out] = i;
		}
	}

	cout << "Completed building the albatross validation labels dataset" << endl;
	cout << "Completed writing the albatross validation pixels" << endl;
}

void ImageDataset::CreateDatasetCheetah(ostream& os)
{
	glob(FLAGS_input_dir + "/ImageNetSubset/cheetah_train/*.jpg", fn1, true);

	cout << "Writing the cheetah train pixels" << endl;

	for (int i=0; i< fn1.size(); i++)
	{
		image = imread(fn1[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res1;
			res1 << i;
			string name_train = res1.str();
			string out_file = FLAGS_input_dir + "/cheetah_formatted_train/"+name_train+".jpg";
			Mat copyImg_train;
			image.copyTo(copyImg_train);
			imwrite(out_file,copyImg_train);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "train" << fn1.size() + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() -1 ; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = fn1.size() + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["train"+out] = value;
		}
	}

	cout << "Completed building the cheetah train labels dataset" << endl;
	cout << "Completed writing the cheetah train pixels" << endl;

	glob(FLAGS_input_dir + "/ImageNetSubset/cheetah_test/*.jpg", fn2, true);

	cout << "Writing the cheetah test pixels" << endl;

	for (int i=0; i< fn2.size(); i++)
	{
		image = imread(fn2[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res2;
			res2 << i;
			string name_test = res2.str();
			string out_file = FLAGS_input_dir + "/cheetah_formatted_test/"+name_test+".jpg";
			Mat copyImg_test;
			image.copyTo(copyImg_test);
			imwrite(out_file,copyImg_test);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "test" << fn2.size() + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() -1 ; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = fn2.size() + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["test"+out] = value;
		}
	}

	cout << "Completed building the cheetah test labels dataset" << endl;
	cout << "Completed writing the cheetah test pixels" << endl;


	glob(FLAGS_input_dir+ "/ImageNetSubset/cheetah_validation/*.jpg", fn3, true);

	cout << "Writing the cheetah validation pixels" << endl;

	for (int i=0; i < fn3.size(); i++)
	{
		image = imread(fn3[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res3;
			res3 << i;
			string name_validation = res3.str();
			string out_file = FLAGS_input_dir + "/cheetah_formatted_validation/"+name_validation+".jpg";
			Mat copyImg_validation;
			image.copyTo(copyImg_validation);
			imwrite(out_file,copyImg_validation);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}


			os << "validation" << fn3.size() + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() -1 ; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = fn3.size() + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["validation"+out] = value;
		}
	}

	cout << "Completed building the cheetah validation labels dataset" << endl;
	cout << "Completed writing the cheetah validation pixels" << endl;

}

void ImageDataset::CreateDatasetGiraffe(ostream& os)
{
	glob(FLAGS_input_dir + "/ImageNetSubset/giraffe_train/*.jpg", fn1, true);

	cout << "Writing the giraffe train pixels" << endl;

	for (int i=0; i < fn1.size(); i++)
	{
		image = imread(fn1[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res1;
			res1 << i;
			string name_train = res1.str();
			string out_file = FLAGS_input_dir + "/giraffe_formatted_train/"+name_train+".jpg";
			Mat copyImg_train;
			image.copyTo(copyImg_train);
			imwrite(out_file,copyImg_train);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "train" << (2*fn1.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() -1 ; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (2*fn1.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["train"+out] = value;
		}
	}

	cout << "Completed building the giraffe train labels dataset" << endl;
	cout << "Completed writing the giraffe train pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/giraffe_test/*.jpg", fn2, true);

	cout << "Writing the giraffe test pixels" << endl;

	for (int i=0; i < fn2.size(); i++)
	{
		image = imread(fn2[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res2;
			res2 << i;
			string name_test = res2.str();
			string out_file = FLAGS_input_dir + "/giraffe_formatted_test/"+name_test+".jpg";
			Mat copyImg_test;
			image.copyTo(copyImg_test);
			imwrite(out_file,copyImg_test);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "test" << (2*fn2.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() -1 ; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (2*fn2.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["test"+out] = value;
		}
	}

	cout << "Completed building the giraffe test labels dataset" << endl;
	cout << "Completed writing the giraffe test pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/giraffe_validation/*.jpg", fn3, true);

	cout << "Writing the giraffe validation pixels" << endl;

	for (int i=0; i < fn3.size(); i++)
	{
		image = imread(fn3[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res3;
			res3 << i;
			string name_validation = res3.str();
			string out_file = FLAGS_input_dir + " /giraffe_formatted_validation/"+name_validation+".jpg";
			Mat copyImg_validation;
			image.copyTo(copyImg_validation);
			imwrite(out_file,copyImg_validation);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "validation" << (2*fn3.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() -1 ; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (2*fn3.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["validation"+out] = value;
		}
	}

	cout << "Completed building the giraffe validation labels dataset" << endl;
	cout << "Completed writing the giraffe validation pixels" << endl;
}


void ImageDataset::CreateDatasetOstrich(ostream& os)
{
	glob(FLAGS_input_dir + "/ImageNetSubset/ostrich_train/*.jpg", fn1, true);

	cout << "Writing the ostrich train pixels" << endl;

	for (int i=0; i< fn1.size(); i++)
	{
		image = imread(fn1[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res1;
			res1 << i;
			string name_train = res1.str();
			string out_file = FLAGS_input_dir + "/ostrich_formatted_train/"+name_train+".jpg";
			Mat copyImg_train;
			image.copyTo(copyImg_train);
			imwrite(out_file,copyImg_train);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "train" << (3*fn1.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (3*fn1.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["train"+out] = value;
		}
	}

	cout << "Completed building the ostrich train labels dataset" << endl;
	cout << "Completed writing the ostrich train pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/ostrich_test/*.jpg", fn2, true);

	cout << "Writing the ostrich test pixels" << endl;

	for (int i=0; i<fn2.size(); i++)
	{
		image = imread(fn2[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res2;
			res2 << i;
			string name_test = res2.str();
			string out_file = FLAGS_input_dir + "/ostrich_formatted_test/"+name_test+".jpg";
			Mat copyImg_test;
			image.copyTo(copyImg_test);
			imwrite(out_file,copyImg_test);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "test" << (3*fn2.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (3*fn2.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["test"+out] = value;
		}
	}

	cout << "Completed building the ostrich test labels dataset" << endl;
	cout << "Completed writing the ostrich test pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/ostrich_validation/*.jpg", fn3, true);

	cout << "Writing the ostrich validation pixels" << endl;

	for (int i=0; i<fn3.size(); i++)
	{
		image = imread(fn3[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res3;
			res3 << i;
			string name_validation = res3.str();
			string out_file =FLAGS_input_dir + "/ostrich_formatted_validation/"+name_validation+".jpg";
			Mat copyImg_validation;
			image.copyTo(copyImg_validation);
			imwrite(out_file,copyImg_validation);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "validation" << (3*fn3.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (3*fn3.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["validation"+out] = value;
		}
	}

	cout << "Completed building the ostrich validation labels dataset" << endl;
	cout << "Completed writing the ostrich validation pixels" << endl;
}

void ImageDataset::CreateDatasetPenguin(ostream& os)
{
	glob(FLAGS_input_dir + "/ImageNetSubset/penguin_train/*.jpg", fn1, true);

	cout << "Writing the penguin train pixels" << endl;

	for (int i=0; i < fn1.size(); i++)
	{
		image = imread(fn1[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res1;
			res1 << i;
			string name_train = res1.str();
			string out_file = FLAGS_input_dir + "/penguin_formatted_train/"+name_train+".jpg";
			Mat copyImg_train;
			image.copyTo(copyImg_train);
			imwrite(out_file,copyImg_train);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "train" << (4*fn1.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (4*fn1.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["train"+out] = value;
		}
	}

	cout << "Completed building the penguin train labels dataset" << endl;
	cout << "Completed writing the penguin train pixels" << endl;



	glob(FLAGS_input_dir + "/ImageNetSubset/penguin_test/*.jpg", fn2, true);

	cout << "Writing the penguin test pixels" << endl;



	for (int i=0; i< fn2.size(); i++)
	{
		image = imread(fn2[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res2;
			res2 << i;
			string name_test = res2.str();
			string out_file = FLAGS_input_dir + "/penguin_formatted_test/"+name_test+".jpg";
			Mat copyImg_test;
			image.copyTo(copyImg_test);
			imwrite(out_file,copyImg_test);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "test" << (4*fn2.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (4*fn2.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["test"+out] = value;
		}
	}

	cout << "Completed building the penguin test labels dataset" << endl;
	cout << "Completed writing the penguin test pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/penguin_validation/*.jpg", fn3, true);

	cout << "Writing the penguin validation pixels" << endl;

	for (int i=0; i<fn3.size(); i++)
	{
		image = imread(fn3[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res3;
			res3 << i;
			string name_validation = res3.str();
			string out_file = FLAGS_input_dir + "/penguin_formatted_validation/"+name_validation+".jpg";
			Mat copyImg_validation;
			image.copyTo(copyImg_validation);
			imwrite(out_file,copyImg_validation);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "validation" << (4*fn3.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (4*fn3.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["validation"+out] = value;
		}
	}

	cout << "Completed building the penguin validation labels dataset" << endl;
	cout << "Completed writing the penguin validation pixels" << endl;
}

void ImageDataset::CreateDatasetTiger(ostream& os)
{
	glob(FLAGS_input_dir + "/ImageNetSubset/tiger_train/*.jpg", fn1, true);

	cout << "Writing the tiger train pixels" << endl;

	for (int i=0; i< fn1.size(); i++)
	{
		image = imread(fn1[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res1;
			res1 << i;
			string name_train = res1.str();
			string out_file = FLAGS_input_dir + "/tiger_formatted_train/"+name_train+".jpg";
			Mat copyImg_train;
			image.copyTo(copyImg_train);
			imwrite(out_file,copyImg_train);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "train" << (5*fn1.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (5*fn1.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["train"+out] = value;
		}
	}

	cout << "Completed building the tiger train labels dataset" << endl;
	cout << "Completed writing the tiger train pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/tiger_test/*.jpg", fn2, true);

	cout << "Writing the tiger test pixels" << endl;

	for (int i=0; i < fn2.size(); i++)
	{
		image = imread(fn2[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res2;
			res2 << i;
			string name_test = res2.str();
			string out_file = FLAGS_input_dir + "/tiger_formatted_test/"+name_test+".jpg";
			Mat copyImg_test;
			image.copyTo(copyImg_test);
			imwrite(out_file,copyImg_test);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "test" << (5*fn2.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (5*fn2.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["test"+out] = value;
		}
	}

	cout << "Completed building the tiger test labels dataset" << endl;
	cout << "Completed writing the tiger test pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/tiger_validation/*.jpg", fn3, true);

	cout << "Writing the tiger validation pixels" << endl;

	for (int i=0; i< fn3.size(); i++)
	{
		image = imread(fn3[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res3;
			res3 << i;
			string name_validation = res3.str();
			string out_file = FLAGS_input_dir + "/tiger_formatted_validation/"+name_validation+".jpg";
			Mat copyImg_validation;
			image.copyTo(copyImg_validation);
			imwrite(out_file,copyImg_validation);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "validation" << (5*fn3.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (5*fn3.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["validation"+out] = value;
		}
	}

	cout << "Completed building the tiger validation labels dataset" << endl;
	cout << "Completed writing the tiger validation pixels" << endl;
}

void ImageDataset::CreateDatasetZebra(ostream& os)
{

	glob(FLAGS_input_dir + "/ImageNetSubset/zebra_train/*.jpg", fn1, true);

	cout << "Writing the zebra train pixels" << endl;

	for (int i=0; i< fn1.size(); i++)
	{
		image = imread(fn1[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res1;
			res1 << i;
			string name_train = res1.str();
			string out_file = FLAGS_input_dir + "/zebra_formatted_train/"+name_train+".jpg";
			Mat copyImg_train;
			image.copyTo(copyImg_train);
			imwrite(out_file,copyImg_train);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "train" << (6*fn1.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (6*fn1.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["train"+out] = value;
		}
	}

	cout << "Completed building the zebra train labels dataset" << endl;
	cout << "Completed writing the zebra train pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/zebra_test/*.jpg", fn2, true);

	cout << "Writing the zebra test pixels" << endl;

	for (int i=0; i< fn2.size(); i++)
	{
		image = imread(fn2[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res2;
			res2 << i;
			string name_test = res2.str();
			string out_file = FLAGS_input_dir + "/zebra_formatted_test/"+name_test+".jpg";
			Mat copyImg_test;
			image.copyTo(copyImg_test);
			imwrite(out_file,copyImg_test);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "test" << (6*fn2.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (6*fn2.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["test"+out] = value;
		}
	}

	cout << "Completed building the zebra test labels dataset" << endl;
	cout << "Completed writing the zebra test pixels" << endl;


	glob(FLAGS_input_dir + "/ImageNetSubset/zebra_validation/*.jpg", fn3, true);

	cout << "Writing the zebra validation pixels" << endl;

	for (int i=0; i<fn3.size(); i++)
	{
		image = imread(fn3[i]);
		resize(image, image, Size(FLAGS_image_size,FLAGS_image_size), 0, 0, INTER_CUBIC);
		if((image.rows == FLAGS_image_size) && (image.cols == FLAGS_image_size))
		{
			stringstream res3;
			res3 << i;
			string name_validation = res3.str();
			string out_file = FLAGS_input_dir + "/zebra_formatted_validation/"+name_validation+".jpg";
			Mat copyImg_validation;
			image.copyTo(copyImg_validation);
			imwrite(out_file,copyImg_validation);

			image_pixels.clear();
			for(int i = 0; i < image.rows; ++i)
			{
				for(int j = 0; j < image.cols; ++j)
				{
					Vec3b intensity = image.at<Vec3b>(j,i);
					image_pixels.push_back(intensity.val[0]);
					image_pixels.push_back(intensity.val[1]);
					image_pixels.push_back(intensity.val[2]);

				}
			}

			os << "validation" << (6*fn3.size()) + i << ";" << "FET;";

			for(int i = 0; i < image_pixels.size() - 1; ++i)
			{
				os << i << ":" << image_pixels[i] << ",";
			}

			os << image_pixels.size() - 1 << ":" << image_pixels[image_pixels.size() - 1] << endl;

			int value = (6*fn3.size()) + i;
			string out = boost::lexical_cast<string>(value);
			dataset_all_patterns["validation"+out] = value;
		}
	}

	cout << "Completed building the zebra validation labels dataset" << endl;
	cout << "Completed writing the zebra validation pixels" << endl;
}


#if FULLYLABEL==1

void ImageDataset::SaveinTrainFL(const string& filename)
{
	ofstream os(filename.c_str());
	if(this->SaveToStreamFL(os, 0, FLAGS_training_size))
		cout << "Train examples written successfully" << endl;
	else
		cout << "Train examples not written successfully" << endl;
	os.close();
}

void ImageDataset::SaveinTestFL(const string& filename)
{
	ofstream os(filename.c_str());
	if(this->SaveToStreamFL(os, FLAGS_training_size, (FLAGS_training_size + FLAGS_test_size)))
		cout << "Test examples written successfully" << endl;
	else
		cout << "Train examples not written successfully" << endl;
	os.close();
}

void ImageDataset::SaveinValidationFL(const string& filename)
{
	ofstream os(filename.c_str());
	if(this->SaveToStreamFL(os,(FLAGS_training_size + FLAGS_test_size), (FLAGS_training_size + FLAGS_test_size + FLAGS_validation_size)))
		cout << "Validation examples written successfully" << endl;
	else
		cout << "Train, Test or Validation examples not written successfully" << endl;
	os.close();
}


void ImageDataset::RandomShuffleData()
{
	for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
	{
		shuffle_temp.push_back(it->first);
	}
	random_shuffle(shuffle_temp.begin(),shuffle_temp.end());

}

bool ImageDataset::SaveToStreamFL(ostream& os, int startSize, int endSize)
{
	int flag = 0;

	for(int i = startSize; i< endSize; ++i)
	{
		boost::regex re1("train");
		boost::regex re2("test");
		boost::regex re3("valid");

		bool match1 = boost::regex_search(shuffle_temp[i],re1);
		if(match1)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second >=0) && (it->second < fn1.size())))
				{
					os << "HAIR(" << it->first << ")=0" << endl;
					os << "MILK(" << it->first << ")=0" << endl;
					os << "MAMMAL(" << it->first << ")=0" << endl;
					os << "FEATHER(" << it->first << ")=1" << endl;
					os << "FLY(" << it->first << ")=1" << endl;
					os << "BIRD(" << it->first << ")=1" << endl;
					os << "LAYEGGS(" << it->first << ")=1" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=1" << endl;
					os << "ALBATROSS(" << it->first << ")=1" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}

			}
		}


		bool match2 = boost::regex_search(shuffle_temp[i],re2);
		if(match2)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second >=0) && (it->second < fn2.size())))
				{
					os << "HAIR(" << it->first << ")=0" << endl;
					os << "MILK(" << it->first << ")=0" << endl;
					os << "MAMMAL(" << it->first << ")=0" << endl;
					os << "FEATHER(" << it->first << ")=1" << endl;
					os << "FLY(" << it->first << ")=1" << endl;
					os << "BIRD(" << it->first << ")=1" << endl;
					os << "LAYEGGS(" << it->first << ")=1" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=1" << endl;
					os << "ALBATROSS(" << it->first << ")=1" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}


		bool match3 = boost::regex_search(shuffle_temp[i],re3);
		if(match3)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second >=0) && (it->second < fn3.size())))
				{
					os << "HAIR(" << it->first << ")=0" << endl;
					os << "MILK(" << it->first << ")=0" << endl;
					os << "MAMMAL(" << it->first << ")=0" << endl;
					os << "FEATHER(" << it->first << ")=1" << endl;
					os << "FLY(" << it->first << ")=1" << endl;
					os << "BIRD(" << it->first << ")=1" << endl;
					os << "LAYEGGS(" << it->first << ")=1" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=1" << endl;
					os << "ALBATROSS(" << it->first << ")=1" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}


		bool match4 = boost::regex_search(shuffle_temp[i],re1);
		if(match4)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > (fn1.size()-1)) && (it->second < (2*fn1.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=1" << endl;
					os << "CARNIVORE(" << it->first << ")=1" << endl;
					os << "POINTEDTEETH(" << it->first << ")=1" << endl;
					os << "CLAWS(" << it->first << ")=1" << endl;
					os << "FORWARDEYES(" << it->first << ")=1" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=1" << endl;
					os << "DARKSPOTS(" << it->first << ")=1" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=1" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match5 = boost::regex_search(shuffle_temp[i],re2);
		if(match5)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > (fn2.size()-1)) && (it->second < (2*fn2.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=1" << endl;
					os << "CARNIVORE(" << it->first << ")=1" << endl;
					os << "POINTEDTEETH(" << it->first << ")=1" << endl;
					os << "CLAWS(" << it->first << ")=1" << endl;
					os << "FORWARDEYES(" << it->first << ")=1" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=1" << endl;
					os << "DARKSPOTS(" << it->first << ")=1" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=1" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match6 = boost::regex_search(shuffle_temp[i],re3);
		if(match6)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > (fn3.size()-1)) && (it->second < (2* fn3.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=1" << endl;
					os << "CARNIVORE(" << it->first << ")=1" << endl;
					os << "POINTEDTEETH(" << it->first << ")=1" << endl;
					os << "CLAWS(" << it->first << ")=1" << endl;
					os << "FORWARDEYES(" << it->first << ")=1" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=1" << endl;
					os << "DARKSPOTS(" << it->first << ")=1" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=1" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match7 = boost::regex_search(shuffle_temp[i],re1);
		if(match7)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((2*fn1.size())-1)) && (it->second < (3* fn1.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=1" << endl;
					os << "UNGULATE(" << it->first << ")=1" << endl;
					os << "EVENTOED(" << it->first << ")=1" << endl;
					os << "CUD(" << it->first << ")=1" << endl;
					os << "TAWNY(" << it->first << ")=1" << endl;
					os << "DARKSPOTS(" << it->first << ")=1" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=1" << endl;
					os << "LONGNECK(" << it->first << ")=1" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=1" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match8 = boost::regex_search(shuffle_temp[i],re2);
		if(match8)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((2* fn2.size())-1)) && (it->second < (3 * fn2.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=1" << endl;
					os << "UNGULATE(" << it->first << ")=1" << endl;
					os << "EVENTOED(" << it->first << ")=1" << endl;
					os << "CUD(" << it->first << ")=1" << endl;
					os << "TAWNY(" << it->first << ")=1" << endl;
					os << "DARKSPOTS(" << it->first << ")=1" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=1" << endl;
					os << "LONGNECK(" << it->first << ")=1" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=1" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}


		bool match9 = boost::regex_search(shuffle_temp[i],re3);
		if(match9)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((2 *fn3.size())-1)) && (it->second < (3* fn3.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=1" << endl;
					os << "UNGULATE(" << it->first << ")=1" << endl;
					os << "EVENTOED(" << it->first << ")=1" << endl;
					os << "CUD(" << it->first << ")=1" << endl;
					os << "TAWNY(" << it->first << ")=1" << endl;
					os << "DARKSPOTS(" << it->first << ")=1" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=1" << endl;
					os << "LONGNECK(" << it->first << ")=1" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=1" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}


		bool match10 = boost::regex_search(shuffle_temp[i],re1);
		if(match10)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((3 * fn1.size())-1)) && (it->second < (4* fn1.size()))))
				{
					os << "HAIR(" << it->first << ")=0" << endl;
					os << "MILK(" << it->first << ")=0" << endl;
					os << "MAMMAL(" << it->first << ")=0" << endl;
					os << "FEATHER(" << it->first << ")=1" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=1" << endl;
					os << "LAYEGGS(" << it->first << ")=1" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=1" << endl;
					os << "LONGNECK(" << it->first << ")=1" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=1" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=1" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}


		bool match11 = boost::regex_search(shuffle_temp[i],re2);
		if(match11)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((3*fn2.size())-1)) && (it->second < (4* fn2.size()))))
				{
					os << "HAIR(" << it->first << ")=0" << endl;
					os << "MILK(" << it->first << ")=0" << endl;
					os << "MAMMAL(" << it->first << ")=0" << endl;
					os << "FEATHER(" << it->first << ")=1" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=1" << endl;
					os << "LAYEGGS(" << it->first << ")=1" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=1" << endl;
					os << "LONGNECK(" << it->first << ")=1" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=1" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=1" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match12 = boost::regex_search(shuffle_temp[i],re3);
		if(match12)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((3 * fn3.size())-1)) && (it->second < (4 * fn3.size()))))
				{
					os << "HAIR(" << it->first << ")=0" << endl;
					os << "MILK(" << it->first << ")=0" << endl;
					os << "MAMMAL(" << it->first << ")=0" << endl;
					os << "FEATHER(" << it->first << ")=1" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=1" << endl;
					os << "LAYEGGS(" << it->first << ")=1" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=1" << endl;
					os << "LONGNECK(" << it->first << ")=1" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=1" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=1" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}

		}

		bool match13 = boost::regex_search(shuffle_temp[i],re1);
		if(match13)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((4 *fn1.size()) - 1)) && (it->second < (5 * fn1.size()))))
				{
					os << "HAIR(" << it->first << ")=0" << endl;
					os << "MILK(" << it->first << ")=0" << endl;
					os << "MAMMAL(" << it->first << ")=0" << endl;
					os << "FEATHER(" << it->first << ")=1" << endl;
					os << "FLY(" << it->first << ")=1" << endl;
					os << "BIRD(" << it->first << ")=1" << endl;
					os << "LAYEGGS(" << it->first << ")=1" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=1" << endl;
					os << "BLACKWHITE(" << it->first << ")=1" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=1" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match14 = boost::regex_search(shuffle_temp[i],re2);
		if(match14)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((4 *fn2.size()) - 1)) && (it->second < (5 * fn2.size()))))
				{


					os << "HAIR(" << it->first << ")=0" << endl;
					os << "MILK(" << it->first << ")=0" << endl;
					os << "MAMMAL(" << it->first << ")=0" << endl;
					os << "FEATHER(" << it->first << ")=1" << endl;
					os << "FLY(" << it->first << ")=1" << endl;
					os << "BIRD(" << it->first << ")=1" << endl;
					os << "LAYEGGS(" << it->first << ")=1" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=1" << endl;
					os << "BLACKWHITE(" << it->first << ")=1" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=1" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match15 = boost::regex_search(shuffle_temp[i],re3);
		if(match15)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((4 * fn3.size())-1)) && (it->second < (5 * fn3.size()))))
				{
					os << "HAIR(" << it->first << ")=0" << endl;
					os << "MILK(" << it->first << ")=0" << endl;
					os << "MAMMAL(" << it->first << ")=0" << endl;
					os << "FEATHER(" << it->first << ")=1" << endl;
					os << "FLY(" << it->first << ")=1" << endl;
					os << "BIRD(" << it->first << ")=1" << endl;
					os << "LAYEGGS(" << it->first << ")=1" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=0" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=1" << endl;
					os << "BLACKWHITE(" << it->first << ")=1" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=1" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match16 = boost::regex_search(shuffle_temp[i],re1);
		if(match16)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((5 * fn1.size())-1)) && (it->second < (6 * fn1.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=1" << endl;
					os << "CARNIVORE(" << it->first << ")=1" << endl;
					os << "POINTEDTEETH(" << it->first << ")=1" << endl;
					os << "CLAWS(" << it->first << ")=1" << endl;
					os << "FORWARDEYES(" << it->first << ")=1" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=1" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=1" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match17 = boost::regex_search(shuffle_temp[i],re2);
		if(match17)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((5 * fn2.size())-1)) && (it->second < (6 * fn2.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=1" << endl;
					os << "CARNIVORE(" << it->first << ")=1" << endl;
					os << "POINTEDTEETH(" << it->first << ")=1" << endl;
					os << "CLAWS(" << it->first << ")=1" << endl;
					os << "FORWARDEYES(" << it->first << ")=1" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=1" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=1" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match18 = boost::regex_search(shuffle_temp[i],re3);
		if(match18)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((5 * fn3.size())-1)) && (it->second < (6 * fn3.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=1" << endl;
					os << "CARNIVORE(" << it->first << ")=1" << endl;
					os << "POINTEDTEETH(" << it->first << ")=1" << endl;
					os << "CLAWS(" << it->first << ")=1" << endl;
					os << "FORWARDEYES(" << it->first << ")=1" << endl;
					os << "HOOFS(" << it->first << ")=0" << endl;
					os << "UNGULATE(" << it->first << ")=0" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=0" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=1" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=0" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=1" << endl;
					os << "ZEBRA(" << it->first << ")=0" << endl;
				}
			}
		}

		bool match19 = boost::regex_search(shuffle_temp[i],re1);
		if(match19)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((6 * fn1.size())-1)) && (it->second < (7* fn1.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=1" << endl;
					os << "UNGULATE(" << it->first << ")=1" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=1" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=1" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=1" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=1" << endl;
				}
			}
		}

		bool match20 = boost::regex_search(shuffle_temp[i],re2);
		if(match20)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((6 * fn2.size())-1)) && (it->second < (7* fn2.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=1" << endl;
					os << "UNGULATE(" << it->first << ")=1" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=1" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=1" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=1" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=1" << endl;
				}
			}
		}

		bool match21 = boost::regex_search(shuffle_temp[i],re3);
		if(match21)
		{
			for(map<string, int>::iterator it=dataset_all_patterns.begin(); it!= dataset_all_patterns.end(); ++it)
			{
				if((shuffle_temp[i] == it->first)&& ((it->second > ((6 * fn3.size())-1)) && (it->second < (7* fn3.size()))))
				{
					os << "HAIR(" << it->first << ")=1" << endl;
					os << "MILK(" << it->first << ")=1" << endl;
					os << "MAMMAL(" << it->first << ")=1" << endl;
					os << "FEATHER(" << it->first << ")=0" << endl;
					os << "FLY(" << it->first << ")=0" << endl;
					os << "BIRD(" << it->first << ")=0" << endl;
					os << "LAYEGGS(" << it->first << ")=0" << endl;
					os << "MEAT(" << it->first << ")=0" << endl;
					os << "CARNIVORE(" << it->first << ")=0" << endl;
					os << "POINTEDTEETH(" << it->first << ")=0" << endl;
					os << "CLAWS(" << it->first << ")=0" << endl;
					os << "FORWARDEYES(" << it->first << ")=0" << endl;
					os << "HOOFS(" << it->first << ")=1" << endl;
					os << "UNGULATE(" << it->first << ")=1" << endl;
					os << "EVENTOED(" << it->first << ")=0" << endl;
					os << "CUD(" << it->first << ")=1" << endl;
					os << "TAWNY(" << it->first << ")=0" << endl;
					os << "DARKSPOTS(" << it->first << ")=0" << endl;
					os << "BLACKSTRIPES(" << it->first << ")=1" << endl;
					os << "LONGLEGS(" << it->first << ")=0" << endl;
					os << "LONGNECK(" << it->first << ")=0" << endl;
					os << "WHITE(" << it->first << ")=1" << endl;
					os << "BLACK(" << it->first << ")=0" << endl;
					os << "SWIM(" << it->first << ")=0" << endl;
					os << "BLACKWHITE(" << it->first << ")=0" << endl;
					os << "GOODFLIER(" << it->first << ")=0" << endl;
					os << "ALBATROSS(" << it->first << ")=0" << endl;
					os << "CHEETAH(" << it->first << ")=0" << endl;
					os << "GIRAFFE(" << it->first << ")=0" << endl;
					os << "OSTRICH(" << it->first << ")=0" << endl;
					os << "PENGUIN(" << it->first << ")=0" << endl;
					os << "TIGER(" << it->first << ")=0" << endl;
					os << "ZEBRA(" << it->first << ")=1" << endl;
				}
			}
		}

		flag = 1;
	}

	if(flag == 1)
		return true;
	else
		return false;
}
#endif

#if PARTIALLABEL==1

void ImageDataset::ExamplesShuffle()
{
	for(int i = 0; i < fn1.size(); ++i)
	{
		string hair = "HAIR(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hair);
		string milk = "MILK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(milk);
		string mammal = "MAMMAL(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(mammal);
		string feather = "FEATHER(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(feather);
		string fly = "FLY(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(fly);
		string bird = "BIRD(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(layeggs);
		string meat = "MEAT(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(train"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);

	}
	for(int i = fn1.size(); i < (2*fn1.size()); ++i)
	{
		string hair = "HAIR(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(train"+ boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (2* fn1.size()); i < (3* fn1.size()); ++i)
	{
		string hair = "HAIR(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(train"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(eventoed);
		string cud = "CUD(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(cud);
		string tawny = "TAWNY(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longneck);
		string white = "WHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (3* fn1.size()); i < (4*fn1.size()); ++i)
	{
		string hair = "HAIR(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hair);
		string milk = "MILK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(milk);
		string mammal = "MAMMAL(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(mammal);
		string feather = "FEATHER(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(feather);
		string fly = "FLY(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(layeggs);
		string meat = "MEAT(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(train"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longneck);
		string white = "WHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(black);
		string swim = "SWIM(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (4*fn1.size()); i < (5*fn1.size()); ++i)
	{
		string hair = "HAIR(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hair);
		string milk = "MILK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(milk);
		string mammal = "MAMMAL(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(mammal);
		string feather = "FEATHER(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(feather);
		string fly = "FLY(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(fly);
		string bird = "BIRD(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(layeggs);
		string meat = "MEAT(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(train"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(penguin);
		string tiger = "TIGER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (5*fn1.size()); i < (6*fn1.size()); ++i)
	{
		string hair = "HAIR(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(train"+ boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(tiger);
		string zebra = "ZEBRA(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (6*fn1.size()); i < (7*fn1.size()); ++i)
	{
		string hair = "HAIR(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(train"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(white);
		string black = "BLACK(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(train" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(train" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(zebra);
	}

	for(int i = 0; i < fn2.size(); ++i)
	{
		string hair = "HAIR(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hair);
		string milk = "MILK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(milk);
		string mammal = "MAMMAL(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(mammal);
		string feather = "FEATHER(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(feather);
		string fly = "FLY(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(fly);
		string bird = "BIRD(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(layeggs);
		string meat = "MEAT(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(test"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = fn2.size(); i < (2 * fn2.size()); ++i)
	{
		string hair = "HAIR(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(test"+ boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (2* fn2.size()); i < (3*fn2.size()); ++i)
	{
		string hair = "HAIR(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(test"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(eventoed);
		string cud = "CUD(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(cud);
		string tawny = "TAWNY(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longneck);
		string white = "WHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (3* fn2.size()); i < (4* fn2.size()); ++i)
	{
		string hair = "HAIR(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hair);
		string milk = "MILK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(milk);
		string mammal = "MAMMAL(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(mammal);
		string feather = "FEATHER(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(feather);
		string fly = "FLY(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(layeggs);
		string meat = "MEAT(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(test"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longneck);
		string white = "WHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(black);
		string swim = "SWIM(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (4*fn2.size()); i < (5*fn2.size()); ++i)
	{
		string hair = "HAIR(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hair);
		string milk = "MILK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(milk);
		string mammal = "MAMMAL(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(mammal);
		string feather = "FEATHER(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(feather);
		string fly = "FLY(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(fly);
		string bird = "BIRD(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(layeggs);
		string meat = "MEAT(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(test"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(penguin);
		string tiger = "TIGER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (5*fn2.size()); i < (6*fn2.size()); ++i)
	{
		string hair = "HAIR(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(test"+ boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(tiger);
		string zebra = "ZEBRA(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (6*fn2.size()); i < (7*fn2.size()); ++i)
	{
		string hair = "HAIR(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(test"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(white);
		string black = "BLACK(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(test" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(test" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(zebra);
	}

	for(int i = 0; i < (fn3.size()); ++i)
	{
		string hair = "HAIR(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hair);
		string milk = "MILK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(milk);
		string mammal = "MAMMAL(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(mammal);
		string feather = "FEATHER(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(feather);
		string fly = "FLY(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(fly);
		string bird = "BIRD(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(layeggs);
		string meat = "MEAT(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(valid"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = fn3.size(); i < (2*fn3.size()); ++i)
	{
		string hair = "HAIR(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(valid"+ boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (2*fn3.size()); i < (3*fn3.size()); ++i)
	{
		string hair = "HAIR(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(valid"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(eventoed);
		string cud = "CUD(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(cud);
		string tawny = "TAWNY(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longneck);
		string white = "WHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (3*fn3.size()); i < (4*fn3.size()); ++i)
	{
		string hair = "HAIR(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hair);
		string milk = "MILK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(milk);
		string mammal = "MAMMAL(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(mammal);
		string feather = "FEATHER(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(feather);
		string fly = "FLY(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(layeggs);
		string meat = "MEAT(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(valid"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(longneck);
		string white = "WHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(black);
		string swim = "SWIM(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (4*fn3.size()); i < (5*fn3.size()); ++i)
	{
		string hair = "HAIR(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hair);
		string milk = "MILK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(milk);
		string mammal = "MAMMAL(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(mammal);
		string feather = "FEATHER(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(feather);
		string fly = "FLY(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(fly);
		string bird = "BIRD(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(layeggs);
		string meat = "MEAT(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(valid"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(penguin);
		string tiger = "TIGER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);;
	}

	for(int i = (5*fn3.size()); i < (6*fn3.size()); ++i)
	{
		string hair = "HAIR(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(valid"+ boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(white);
		string black = "BLACK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(tiger);
		string zebra = "ZEBRA(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(zebra);
	}

	for(int i = (6*fn3.size()); i < (7*fn3.size()); ++i)
	{
		string hair = "HAIR(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hair);
		string milk = "MILK(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(milk);
		string mammal = "MAMMAL(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(mammal);
		string feather = "FEATHER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(feather);
		string fly = "FLY(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(fly);
		string bird = "BIRD(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(bird);
		string layeggs = "LAYEGGS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(layeggs);
		string meat = "MEAT(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(meat);
		string carnivore = "CARNIVORE(valid"+ boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(carnivore);
		string pointedteeth = "POINTEDTEETH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(pointedteeth);
		string claws = "CLAWS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(claws);
		string forwardeyes = "FORWARDEYES(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(forwardeyes);
		string hoofs = "HOOFS(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(hoofs);
		string ungulate = "UNGULATE(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(ungulate);
		string eventoed = "EVENTOED(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(eventoed);
		string cud = "CUD(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cud);
		string tawny = "TAWNY(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tawny);
		string darkspots = "DARKSPOTS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(darkspots);
		string blackstripes = "BLACKSTRIPES(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(blackstripes);
		string longlegs = "LONGLEGS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longlegs);
		string longneck = "LONGNECK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(longneck);
		string white = "WHITE(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(white);
		string black = "BLACK(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(black);
		string swim = "SWIM(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(swim);
		string blackwhite ="BLACKWHITE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(blackwhite);
		string goodflier = "GOODFLIER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(goodflier);
		string albatross = "ALBATROSS(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(albatross);
		string cheetah = "CHEETAH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(cheetah);
		string giraffe = "GIRAFFE(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(giraffe);
		string ostrich = "OSTRICH(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(ostrich);
		string penguin = "PENGUIN(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(penguin);
		string tiger = "TIGER(valid" + boost::lexical_cast<std::string>(i) + ")=0";
		lines.push_back(tiger);
		string zebra = "ZEBRA(valid" + boost::lexical_cast<std::string>(i) + ")=1";
		lines.push_back(zebra);
	}


	random_shuffle(lines.begin(), lines.end());

}
void ImageDataset::SaveinTrainPL(const string& filename)
{
	ofstream os(filename.c_str());
	for(int i = 0; i< FLAGS_training_size*33; ++i)
	{
		os << lines[i] << endl;
	}
	cout << "Train examples written successfully" << endl;
	os.close();

}

void ImageDataset::SaveinTestPL(const string& filename)
{
	ofstream os(filename.c_str());

	for(int i = FLAGS_training_size*33; i < (FLAGS_training_size + FLAGS_test_size)*33; ++i)
	{
		os << lines[i] << endl;
	}
	cout << "Test examples written successfully" << endl;
	os.close();
}

void ImageDataset::SaveinValidationPL(const string& filename)
{
	ofstream os(filename.c_str());

	for(int i = (FLAGS_training_size + FLAGS_test_size)*33; i < (FLAGS_training_size + FLAGS_test_size + FLAGS_validation_size)*33; ++i)
	{
		os << lines[i] << endl;
	}
	cout << "Validation examples written successfully" << endl;
	os.close();
}

#endif


#if TRANSSEP ==1

void ImageDataset::SaveinTrainTS(const string& filename)
{
	ofstream os(filename.c_str());

	for(int i = 0; i < fn1.size(); ++i)
	{
		os << "HAIR(train" << i << ")=0" << endl;
		os << "MILK(train" << i << ")=0" << endl;
		os << "MAMMAL(train" << i << ")=0" << endl;
		os << "FEATHER(train" << i << ")=1" << endl;
		os << "FLY(train" << i << ")=1" << endl;
		os << "BIRD(train" << i << ")=1" << endl;
		os << "LAYEGGS(train" << i << ")=1" << endl;
		os << "MEAT(train" << i << ")=0" << endl;
		os << "CARNIVORE(train" << i << ")=0" << endl;
		os << "POINTEDTEETH(train" << i << ")=0" << endl;
		os << "CLAWS(train" << i << ")=0" << endl;
		os << "FORWARDEYES(train" << i << ")=0" << endl;
		os << "HOOFS(train" << i << ")=0" << endl;
		os << "UNGULATE(train" << i << ")=0" << endl;
		os << "EVENTOED(train" << i << ")=0" << endl;
		os << "CUD(train" << i << ")=0" << endl;
		os << "TAWNY(train" << i << ")=0" << endl;
		os << "DARKSPOTS(train" << i << ")=0" << endl;
		os << "BLACKSTRIPES(train" << i << ")=0" << endl;
		os << "LONGLEGS(train" << i << ")=0" << endl;
		os << "LONGNECK(train" << i << ")=0" << endl;
		os << "WHITE(train" << i << ")=0" << endl;
		os << "BLACK(train" << i << ")=0" << endl;
		os << "SWIM(train" << i << ")=0" << endl;
		os << "BLACKWHITE(train" << i << ")=0" << endl;
		os << "GOODFLIER(train" << i << ")=1" << endl;
		os << "ALBATROSS(train" << i << ")=1" << endl;
		os << "CHEETAH(train" << i << ")=0" << endl;
		os << "GIRAFFE(train" << i << ")=0" << endl;
		os << "OSTRICH(train" << i << ")=0" << endl;
		os << "PENGUIN(train" << i << ")=0" << endl;
		os << "TIGER(train" << i << ")=0" << endl;
		os << "ZEBRA(train" << i << ")=0" << endl;
	}

	for(int i = fn1.size(); i < (2*fn1.size()); ++i)
	{
		os << "HAIR(train" << i << ")=1" << endl;
		os << "MILK(train" << i << ")=1" << endl;
		os << "MAMMAL(train" << i << ")=1" << endl;
		os << "FEATHER(train" << i << ")=0" << endl;
		os << "FLY(train" << i << ")=0" << endl;
		os << "BIRD(train" << i << ")=0" << endl;
		os << "LAYEGGS(train" << i << ")=0" << endl;
		os << "MEAT(train" << i << ")=1" << endl;
		os << "CARNIVORE(train" << i << ")=1" << endl;
		os << "POINTEDTEETH(train" << i << ")=1" << endl;
		os << "CLAWS(train" << i << ")=1" << endl;
		os << "FORWARDEYES(train" << i << ")=1" << endl;
		os << "HOOFS(train" << i << ")=0" << endl;
		os << "UNGULATE(train" << i << ")=0" << endl;
		os << "EVENTOED(train" << i << ")=0" << endl;
		os << "CUD(train" << i << ")=0" << endl;
		os << "TAWNY(train" << i << ")=1" << endl;
		os << "DARKSPOTS(train" << i << ")=1" << endl;
		os << "BLACKSTRIPES(train" << i << ")=0" << endl;
		os << "LONGLEGS(train" << i << ")=0" << endl;
		os << "LONGNECK(train" << i << ")=0" << endl;
		os << "WHITE(train" << i << ")=0" << endl;
		os << "BLACK(train" << i << ")=0" << endl;
		os << "SWIM(train" << i << ")=0" << endl;
		os << "BLACKWHITE(train" << i << ")=0" << endl;
		os << "GOODFLIER(train" << i << ")=0" << endl;
		os << "ALBATROSS(train" << i << ")=0" << endl;
		os << "CHEETAH(train" << i << ")=1" << endl;
		os << "GIRAFFE(train" << i << ")=0" << endl;
		os << "OSTRICH(train" << i << ")=0" << endl;
		os << "PENGUIN(train" << i << ")=0" << endl;
		os << "TIGER(train" << i << ")=0" << endl;
		os << "ZEBRA(train" << i << ")=0" << endl;
	}

	for(int i = (2*fn1.size()); i < (3*fn1.size()); ++i)
	{
		os << "HAIR(train" << i << ")=1" << endl;
		os << "MILK(train" << i << ")=1" << endl;
		os << "MAMMAL(train" << i << ")=1" << endl;
		os << "FEATHER(train" << i << ")=0" << endl;
		os << "FLY(train" << i << ")=0" << endl;
		os << "BIRD(train" << i << ")=0" << endl;
		os << "LAYEGGS(train" << i << ")=0" << endl;
		os << "MEAT(train" << i << ")=0" << endl;
		os << "CARNIVORE(train" << i << ")=0" << endl;
		os << "POINTEDTEETH(train" << i << ")=0" << endl;
		os << "CLAWS(train" << i << ")=0" << endl;
		os << "FORWARDEYES(train" << i << ")=0" << endl;
		os << "HOOFS(train" << i << ")=1" << endl;
		os << "UNGULATE(train" << i << ")=1" << endl;
		os << "EVENTOED(train" << i << ")=1" << endl;
		os << "CUD(train" << i << ")=1" << endl;
		os << "TAWNY(train" << i << ")=1" << endl;
		os << "DARKSPOTS(train" << i << ")=1" << endl;
		os << "BLACKSTRIPES(train" << i << ")=0" << endl;
		os << "LONGLEGS(train" << i << ")=1" << endl;
		os << "LONGNECK(train" << i << ")=1" << endl;
		os << "WHITE(train" << i << ")=0" << endl;
		os << "BLACK(train" << i << ")=0" << endl;
		os << "SWIM(train" << i << ")=0" << endl;
		os << "BLACKWHITE(train" << i << ")=0" << endl;
		os << "GOODFLIER(train" << i << ")=0" << endl;
		os << "ALBATROSS(train" << i << ")=0" << endl;
		os << "CHEETAH(train" << i << ")=0" << endl;
		os << "GIRAFFE(train" << i << ")=1" << endl;
		os << "OSTRICH(train" << i << ")=0" << endl;
		os << "PENGUIN(train" << i << ")=0" << endl;
		os << "TIGER(train" << i << ")=0" << endl;
		os << "ZEBRA(train" << i << ")=0" << endl;
	}

	for(int i = (3*fn1.size()); i < (4*fn1.size()); ++i)
	{
		os << "HAIR(train" << i << ")=0" << endl;
		os << "MILK(train" << i << ")=0" << endl;
		os << "MAMMAL(train" << i << ")=0" << endl;
		os << "FEATHER(train" << i << ")=1" << endl;
		os << "FLY(train" << i << ")=0" << endl;
		os << "BIRD(train" << i << ")=1" << endl;
		os << "LAYEGGS(train" << i << ")=1" << endl;
		os << "MEAT(train" << i << ")=0" << endl;
		os << "CARNIVORE(train" << i << ")=0" << endl;
		os << "POINTEDTEETH(train" << i << ")=0" << endl;
		os << "CLAWS(train" << i << ")=0" << endl;
		os << "FORWARDEYES(train" << i << ")=0" << endl;
		os << "HOOFS(train" << i << ")=0" << endl;
		os << "UNGULATE(train" << i << ")=0" << endl;
		os << "EVENTOED(train" << i << ")=0" << endl;
		os << "CUD(train" << i << ")=0" << endl;
		os << "TAWNY(train" << i << ")=0" << endl;
		os << "DARKSPOTS(train" << i << ")=0" << endl;
		os << "BLACKSTRIPES(train" << i << ")=0" << endl;
		os << "LONGLEGS(train" << i << ")=1" << endl;
		os << "LONGNECK(train" << i << ")=1" << endl;
		os << "WHITE(train" << i << ")=0" << endl;
		os << "BLACK(train" << i << ")=1" << endl;
		os << "SWIM(train" << i << ")=0" << endl;
		os << "BLACKWHITE(train" << i << ")=0" << endl;
		os << "GOODFLIER(train" << i << ")=0" << endl;
		os << "ALBATROSS(train" << i << ")=0" << endl;
		os << "CHEETAH(train" << i << ")=0" << endl;
		os << "GIRAFFE(train" << i << ")=0" << endl;
		os << "OSTRICH(train" << i << ")=1" << endl;
		os << "PENGUIN(train" << i << ")=0" << endl;
		os << "TIGER(train" << i << ")=0" << endl;
		os << "ZEBRA(train" << i << ")=0" << endl;
	}

	for(int i = (4*fn1.size()); i < (5*fn1.size()); ++i)
	{
		os << "HAIR(train" << i << ")=0" << endl;
		os << "MILK(train" << i << ")=0" << endl;
		os << "MAMMAL(train" << i << ")=0" << endl;
		os << "FEATHER(train" << i << ")=1" << endl;
		os << "FLY(train" << i << ")=1" << endl;
		os << "BIRD(train" << i << ")=1" << endl;
		os << "LAYEGGS(train" << i << ")=1" << endl;
		os << "MEAT(train" << i << ")=0" << endl;
		os << "CARNIVORE(train" << i << ")=0" << endl;
		os << "POINTEDTEETH(train" << i << ")=0" << endl;
		os << "CLAWS(train" << i << ")=0" << endl;
		os << "FORWARDEYES(train" << i << ")=0" << endl;
		os << "HOOFS(train" << i << ")=0" << endl;
		os << "UNGULATE(train" << i << ")=0" << endl;
		os << "EVENTOED(train" << i << ")=0" << endl;
		os << "CUD(train" << i << ")=0" << endl;
		os << "TAWNY(train" << i << ")=0" << endl;
		os << "DARKSPOTS(train" << i << ")=0" << endl;
		os << "BLACKSTRIPES(train" << i << ")=0" << endl;
		os << "LONGLEGS(train" << i << ")=0" << endl;
		os << "LONGNECK(train" << i << ")=0" << endl;
		os << "WHITE(train" << i << ")=0" << endl;
		os << "BLACK(train" << i << ")=0" << endl;
		os << "SWIM(train" << i << ")=1" << endl;
		os << "BLACKWHITE(train" << i << ")=1" << endl;
		os << "GOODFLIER(train" << i << ")=0" << endl;
		os << "ALBATROSS(train" << i << ")=0" << endl;
		os << "CHEETAH(train" << i << ")=0" << endl;
		os << "GIRAFFE(train" << i << ")=0" << endl;
		os << "OSTRICH(train" << i << ")=0" << endl;
		os << "PENGUIN(train" << i << ")=1" << endl;
		os << "TIGER(train" << i << ")=0" << endl;
		os << "ZEBRA(train" << i << ")=0" << endl;
	}

	for(int i = (5*fn1.size()); i < (6*fn1.size()); ++i)
	{
		os << "HAIR(train" << i << ")=1" << endl;
		os << "MILK(train" << i << ")=1" << endl;
		os << "MAMMAL(train" << i << ")=1" << endl;
		os << "FEATHER(train" << i << ")=0" << endl;
		os << "FLY(train" << i << ")=0" << endl;
		os << "BIRD(train" << i << ")=0" << endl;
		os << "LAYEGGS(train" << i << ")=0" << endl;
		os << "MEAT(train" << i << ")=1" << endl;
		os << "CARNIVORE(train" << i << ")=1" << endl;
		os << "POINTEDTEETH(train" << i << ")=1" << endl;
		os << "CLAWS(train" << i << ")=1" << endl;
		os << "FORWARDEYES(train" << i << ")=1" << endl;
		os << "HOOFS(train" << i << ")=0" << endl;
		os << "UNGULATE(train" << i << ")=0" << endl;
		os << "EVENTOED(train" << i << ")=0" << endl;
		os << "CUD(train" << i << ")=0" << endl;
		os << "TAWNY(train" << i << ")=0" << endl;
		os << "DARKSPOTS(train" << i << ")=0" << endl;
		os << "BLACKSTRIPES(train" << i << ")=1" << endl;
		os << "LONGLEGS(train" << i << ")=0" << endl;
		os << "LONGNECK(train" << i << ")=0" << endl;
		os << "WHITE(train" << i << ")=0" << endl;
		os << "BLACK(train" << i << ")=0" << endl;
		os << "SWIM(train" << i << ")=0" << endl;
		os << "BLACKWHITE(train" << i << ")=0" << endl;
		os << "GOODFLIER(train" << i << ")=0" << endl;
		os << "ALBATROSS(train" << i << ")=0" << endl;
		os << "CHEETAH(train" << i << ")=0" << endl;
		os << "GIRAFFE(train" << i << ")=0" << endl;
		os << "OSTRICH(train" << i << ")=0" << endl;
		os << "PENGUIN(train" << i << ")=0" << endl;
		os << "TIGER(train" << i << ")=1" << endl;
		os << "ZEBRA(train" << i << ")=0" << endl;
	}

	for(int i = (6*fn1.size()); i < (7*fn1.size()); ++i)
	{
		os << "HAIR(train" << i << ")=1" << endl;
		os << "MILK(train" << i << ")=1" << endl;
		os << "MAMMAL(train" << i << ")=1" << endl;
		os << "FEATHER(train" << i << ")=0" << endl;
		os << "FLY(train" << i << ")=0" << endl;
		os << "BIRD(train" << i << ")=0" << endl;
		os << "LAYEGGS(train" << i << ")=0" << endl;
		os << "MEAT(train" << i << ")=0" << endl;
		os << "CARNIVORE(train" << i << ")=0" << endl;
		os << "POINTEDTEETH(train" << i << ")=0" << endl;
		os << "CLAWS(train" << i << ")=0" << endl;
		os << "FORWARDEYES(train" << i << ")=0" << endl;
		os << "HOOFS(train" << i << ")=1" << endl;
		os << "UNGULATE(train" << i << ")=1" << endl;
		os << "EVENTOED(train" << i << ")=0" << endl;
		os << "CUD(train" << i << ")=1" << endl;
		os << "TAWNY(train" << i << ")=0" << endl;
		os << "DARKSPOTS(train" << i << ")=0" << endl;
		os << "BLACKSTRIPES(train" << i << ")=1" << endl;
		os << "LONGLEGS(train" << i << ")=0" << endl;
		os << "LONGNECK(train" << i << ")=0" << endl;
		os << "WHITE(train" << i << ")=1" << endl;
		os << "BLACK(train" << i << ")=0" << endl;
		os << "SWIM(train" << i << ")=0" << endl;
		os << "BLACKWHITE(train" << i << ")=0" << endl;
		os << "GOODFLIER(train" << i << ")=0" << endl;
		os << "ALBATROSS(train" << i << ")=0" << endl;
		os << "CHEETAH(train" << i << ")=0" << endl;
		os << "GIRAFFE(train" << i << ")=0" << endl;
		os << "OSTRICH(train" << i << ")=0" << endl;
		os << "PENGUIN(train" << i << ")=0" << endl;
		os << "TIGER(train" << i << ")=0" << endl;
		os << "ZEBRA(train" << i << ")=1" << endl;
	}

	os.close();

}


void ImageDataset::SaveinTestTS(const string& filename)
{
	ofstream os(filename.c_str());
	for(int i = 0; i < fn2.size(); ++i)
	{
		os << "HAIR(test" << i << ")=0" << endl;
		os << "MILK(test" << i << ")=0" << endl;
		os << "MAMMAL(test" << i << ")=0" << endl;
		os << "FEATHER(test" << i << ")=1" << endl;
		os << "FLY(test" << i << ")=1" << endl;
		os << "BIRD(test" << i << ")=1" << endl;
		os << "LAYEGGS(test" << i << ")=1" << endl;
		os << "MEAT(test" << i << ")=0" << endl;
		os << "CARNIVORE(test" << i << ")=0" << endl;
		os << "POINTEDTEETH(test" << i << ")=0" << endl;
		os << "CLAWS(test" << i << ")=0" << endl;
		os << "FORWARDEYES(test" << i << ")=0" << endl;
		os << "HOOFS(test" << i << ")=0" << endl;
		os << "UNGULATE(test" << i << ")=0" << endl;
		os << "EVENTOED(test" << i << ")=0" << endl;
		os << "CUD(test" << i << ")=0" << endl;
		os << "TAWNY(test" << i << ")=0" << endl;
		os << "DARKSPOTS(test" << i << ")=0" << endl;
		os << "BLACKSTRIPES(test" << i << ")=0" << endl;
		os << "LONGLEGS(test" << i << ")=0" << endl;
		os << "LONGNECK(test" << i << ")=0" << endl;
		os << "WHITE(test" << i << ")=0" << endl;
		os << "BLACK(test" << i << ")=0" << endl;
		os << "SWIM(test" << i << ")=0" << endl;
		os << "BLACKWHITE(test" << i << ")=0" << endl;
		os << "GOODFLIER(test" << i << ")=1" << endl;
		os << "ALBATROSS(test" << i << ")=1" << endl;
		os << "CHEETAH(test" << i << ")=0" << endl;
		os << "GIRAFFE(test" << i << ")=0" << endl;
		os << "OSTRICH(test" << i << ")=0" << endl;
		os << "PENGUIN(test" << i << ")=0" << endl;
		os << "TIGER(test" << i << ")=0" << endl;
		os << "ZEBRA(test" << i << ")=0" << endl;
	}

	for(int i = fn2.size(); i < (2*fn2.size()); ++i)
	{
		os << "HAIR(test" << i << ")=1" << endl;
		os << "MILK(test" << i << ")=1" << endl;
		os << "MAMMAL(test" << i << ")=1" << endl;
		os << "FEATHER(test" << i << ")=0" << endl;
		os << "FLY(test" << i << ")=0" << endl;
		os << "BIRD(test" << i << ")=0" << endl;
		os << "LAYEGGS(test" << i << ")=0" << endl;
		os << "MEAT(test" << i << ")=1" << endl;
		os << "CARNIVORE(test" << i << ")=1" << endl;
		os << "POINTEDTEETH(test" << i << ")=1" << endl;
		os << "CLAWS(test" << i << ")=1" << endl;
		os << "FORWARDEYES(test" << i << ")=1" << endl;
		os << "HOOFS(test" << i << ")=0" << endl;
		os << "UNGULATE(test" << i << ")=0" << endl;
		os << "EVENTOED(test" << i << ")=0" << endl;
		os << "CUD(test" << i << ")=0" << endl;
		os << "TAWNY(test" << i << ")=1" << endl;
		os << "DARKSPOTS(test" << i << ")=1" << endl;
		os << "BLACKSTRIPES(test" << i << ")=0" << endl;
		os << "LONGLEGS(test" << i << ")=0" << endl;
		os << "LONGNECK(test" << i << ")=0" << endl;
		os << "WHITE(test" << i << ")=0" << endl;
		os << "BLACK(test" << i << ")=0" << endl;
		os << "SWIM(test" << i << ")=0" << endl;
		os << "BLACKWHITE(test" << i << ")=0" << endl;
		os << "GOODFLIER(test" << i << ")=0" << endl;
		os << "ALBATROSS(test" << i << ")=0" << endl;
		os << "CHEETAH(test" << i << ")=1" << endl;
		os << "GIRAFFE(test" << i << ")=0" << endl;
		os << "OSTRICH(test" << i << ")=0" << endl;
		os << "PENGUIN(test" << i << ")=0" << endl;
		os << "TIGER(test" << i << ")=0" << endl;
		os << "ZEBRA(test" << i << ")=0" << endl;
	}

	for(int i = (2*fn2.size()); i < (3*fn2.size()); ++i)
	{
		os << "HAIR(test" << i << ")=1" << endl;
		os << "MILK(test" << i << ")=1" << endl;
		os << "MAMMAL(test" << i << ")=1" << endl;
		os << "FEATHER(test" << i << ")=0" << endl;
		os << "FLY(test" << i << ")=0" << endl;
		os << "BIRD(test" << i << ")=0" << endl;
		os << "LAYEGGS(test" << i << ")=0" << endl;
		os << "MEAT(test" << i << ")=0" << endl;
		os << "CARNIVORE(test" << i << ")=0" << endl;
		os << "POINTEDTEETH(test" << i << ")=0" << endl;
		os << "CLAWS(test" << i << ")=0" << endl;
		os << "FORWARDEYES(test" << i << ")=0" << endl;
		os << "HOOFS(test" << i << ")=1" << endl;
		os << "UNGULATE(test" << i << ")=1" << endl;
		os << "EVENTOED(test" << i << ")=1" << endl;
		os << "CUD(test" << i << ")=1" << endl;
		os << "TAWNY(test" << i << ")=1" << endl;
		os << "DARKSPOTS(test" << i << ")=1" << endl;
		os << "BLACKSTRIPES(test" << i << ")=0" << endl;
		os << "LONGLEGS(test" << i << ")=1" << endl;
		os << "LONGNECK(test" << i << ")=1" << endl;
		os << "WHITE(test" << i << ")=0" << endl;
		os << "BLACK(test" << i << ")=0" << endl;
		os << "SWIM(test" << i << ")=0" << endl;
		os << "BLACKWHITE(test" << i << ")=0" << endl;
		os << "GOODFLIER(test" << i << ")=0" << endl;
		os << "ALBATROSS(test" << i << ")=0" << endl;
		os << "CHEETAH(test" << i << ")=0" << endl;
		os << "GIRAFFE(test" << i << ")=1" << endl;
		os << "OSTRICH(test" << i << ")=0" << endl;
		os << "PENGUIN(test" << i << ")=0" << endl;
		os << "TIGER(test" << i << ")=0" << endl;
		os << "ZEBRA(test" << i << ")=0" << endl;
	}

	for(int i = (3*fn2.size()); i < (4*fn2.size()); ++i)
	{
		os << "HAIR(test" << i << ")=0" << endl;
		os << "MILK(test" << i << ")=0" << endl;
		os << "MAMMAL(test" << i << ")=0" << endl;
		os << "FEATHER(test" << i << ")=1" << endl;
		os << "FLY(test" << i << ")=0" << endl;
		os << "BIRD(test" << i << ")=1" << endl;
		os << "LAYEGGS(test" << i << ")=1" << endl;
		os << "MEAT(test" << i << ")=0" << endl;
		os << "CARNIVORE(test" << i << ")=0" << endl;
		os << "POINTEDTEETH(test" << i << ")=0" << endl;
		os << "CLAWS(test" << i << ")=0" << endl;
		os << "FORWARDEYES(test" << i << ")=0" << endl;
		os << "HOOFS(test" << i << ")=0" << endl;
		os << "UNGULATE(test" << i << ")=0" << endl;
		os << "EVENTOED(test" << i << ")=0" << endl;
		os << "CUD(test" << i << ")=0" << endl;
		os << "TAWNY(test" << i << ")=0" << endl;
		os << "DARKSPOTS(test" << i << ")=0" << endl;
		os << "BLACKSTRIPES(test" << i << ")=0" << endl;
		os << "LONGLEGS(test" << i << ")=1" << endl;
		os << "LONGNECK(test" << i << ")=1" << endl;
		os << "WHITE(test" << i << ")=0" << endl;
		os << "BLACK(test" << i << ")=1" << endl;
		os << "SWIM(test" << i << ")=0" << endl;
		os << "BLACKWHITE(test" << i << ")=0" << endl;
		os << "GOODFLIER(test" << i << ")=0" << endl;
		os << "ALBATROSS(test" << i << ")=0" << endl;
		os << "CHEETAH(test" << i << ")=0" << endl;
		os << "GIRAFFE(test" << i << ")=0" << endl;
		os << "OSTRICH(test" << i << ")=1" << endl;
		os << "PENGUIN(test" << i << ")=0" << endl;
		os << "TIGER(test" << i << ")=0" << endl;
		os << "ZEBRA(test" << i << ")=0" << endl;
	}

	for(int i = (4*fn2.size()); i < (5*fn2.size()); ++i)
	{
		os << "HAIR(test" << i << ")=0" << endl;
		os << "MILK(test" << i << ")=0" << endl;
		os << "MAMMAL(test" << i << ")=0" << endl;
		os << "FEATHER(test" << i << ")=1" << endl;
		os << "FLY(test" << i << ")=1" << endl;
		os << "BIRD(test" << i << ")=1" << endl;
		os << "LAYEGGS(test" << i << ")=1" << endl;
		os << "MEAT(test" << i << ")=0" << endl;
		os << "CARNIVORE(test" << i << ")=0" << endl;
		os << "POINTEDTEETH(test" << i << ")=0" << endl;
		os << "CLAWS(test" << i << ")=0" << endl;
		os << "FORWARDEYES(test" << i << ")=0" << endl;
		os << "HOOFS(test" << i << ")=0" << endl;
		os << "UNGULATE(test" << i << ")=0" << endl;
		os << "EVENTOED(test" << i << ")=0" << endl;
		os << "CUD(test" << i << ")=0" << endl;
		os << "TAWNY(test" << i << ")=0" << endl;
		os << "DARKSPOTS(test" << i << ")=0" << endl;
		os << "BLACKSTRIPES(test" << i << ")=0" << endl;
		os << "LONGLEGS(test" << i << ")=0" << endl;
		os << "LONGNECK(test" << i << ")=0" << endl;
		os << "WHITE(test" << i << ")=0" << endl;
		os << "BLACK(test" << i << ")=0" << endl;
		os << "SWIM(test" << i << ")=1" << endl;
		os << "BLACKWHITE(test" << i << ")=1" << endl;
		os << "GOODFLIER(test" << i << ")=0" << endl;
		os << "ALBATROSS(test" << i << ")=0" << endl;
		os << "CHEETAH(test" << i << ")=0" << endl;
		os << "GIRAFFE(test" << i << ")=0" << endl;
		os << "OSTRICH(test" << i << ")=0" << endl;
		os << "PENGUIN(test" << i << ")=1" << endl;
		os << "TIGER(test" << i << ")=0" << endl;
		os << "ZEBRA(test" << i << ")=0" << endl;
	}

	for(int i = (5*fn2.size()); i < (6*fn2.size()); ++i)
	{
		os << "HAIR(test" << i << ")=1" << endl;
		os << "MILK(test" << i << ")=1" << endl;
		os << "MAMMAL(test" << i << ")=1" << endl;
		os << "FEATHER(test" << i << ")=0" << endl;
		os << "FLY(test" << i << ")=0" << endl;
		os << "BIRD(test" << i << ")=0" << endl;
		os << "LAYEGGS(test" << i << ")=0" << endl;
		os << "MEAT(test" << i << ")=1" << endl;
		os << "CARNIVORE(test" << i << ")=1" << endl;
		os << "POINTEDTEETH(test" << i << ")=1" << endl;
		os << "CLAWS(test" << i << ")=1" << endl;
		os << "FORWARDEYES(test" << i << ")=1" << endl;
		os << "HOOFS(test" << i << ")=0" << endl;
		os << "UNGULATE(test" << i << ")=0" << endl;
		os << "EVENTOED(test" << i << ")=0" << endl;
		os << "CUD(test" << i << ")=0" << endl;
		os << "TAWNY(test" << i << ")=0" << endl;
		os << "DARKSPOTS(test" << i << ")=0" << endl;
		os << "BLACKSTRIPES(test" << i << ")=1" << endl;
		os << "LONGLEGS(test" << i << ")=0" << endl;
		os << "LONGNECK(test" << i << ")=0" << endl;
		os << "WHITE(test" << i << ")=0" << endl;
		os << "BLACK(test" << i << ")=0" << endl;
		os << "SWIM(test" << i << ")=0" << endl;
		os << "BLACKWHITE(test" << i << ")=0" << endl;
		os << "GOODFLIER(test" << i << ")=0" << endl;
		os << "ALBATROSS(test" << i << ")=0" << endl;
		os << "CHEETAH(test" << i << ")=0" << endl;
		os << "GIRAFFE(test" << i << ")=0" << endl;
		os << "OSTRICH(test" << i << ")=0" << endl;
		os << "PENGUIN(test" << i << ")=0" << endl;
		os << "TIGER(test" << i << ")=1" << endl;
		os << "ZEBRA(test" << i << ")=0" << endl;
	}

	for(int i = (6*fn2.size()); i < (7*fn2.size()); ++i)
	{
		os << "HAIR(test" << i << ")=1" << endl;
		os << "MILK(test" << i << ")=1" << endl;
		os << "MAMMAL(test" << i << ")=1" << endl;
		os << "FEATHER(test" << i << ")=0" << endl;
		os << "FLY(test" << i << ")=0" << endl;
		os << "BIRD(test" << i << ")=0" << endl;
		os << "LAYEGGS(test" << i << ")=0" << endl;
		os << "MEAT(test" << i << ")=0" << endl;
		os << "CARNIVORE(test" << i << ")=0" << endl;
		os << "POINTEDTEETH(test" << i << ")=0" << endl;
		os << "CLAWS(test" << i << ")=0" << endl;
		os << "FORWARDEYES(test" << i << ")=0" << endl;
		os << "HOOFS(test" << i << ")=1" << endl;
		os << "UNGULATE(test" << i << ")=1" << endl;
		os << "EVENTOED(test" << i << ")=0" << endl;
		os << "CUD(test" << i << ")=1" << endl;
		os << "TAWNY(test" << i << ")=0" << endl;
		os << "DARKSPOTS(test" << i << ")=0" << endl;
		os << "BLACKSTRIPES(test" << i << ")=1" << endl;
		os << "LONGLEGS(test" << i << ")=0" << endl;
		os << "LONGNECK(test" << i << ")=0" << endl;
		os << "WHITE(test" << i << ")=1" << endl;
		os << "BLACK(test" << i << ")=0" << endl;
		os << "SWIM(test" << i << ")=0" << endl;
		os << "BLACKWHITE(test" << i << ")=0" << endl;
		os << "GOODFLIER(test" << i << ")=0" << endl;
		os << "ALBATROSS(test" << i << ")=0" << endl;
		os << "CHEETAH(test" << i << ")=0" << endl;
		os << "GIRAFFE(test" << i << ")=0" << endl;
		os << "OSTRICH(test" << i << ")=0" << endl;
		os << "PENGUIN(test" << i << ")=0" << endl;
		os << "TIGER(test" << i << ")=0" << endl;
		os << "ZEBRA(test" << i << ")=1" << endl;
	}

	os.close();
}


void ImageDataset::SaveinValidationTS(const string& filename)
{
	ofstream os(filename.c_str());
	for(int i = 0; i < fn3.size(); ++i)
	{
		os << "HAIR(validation" << i << ")=0" << endl;
		os << "MILK(validation" << i << ")=0" << endl;
		os << "MAMMAL(validation" << i << ")=0" << endl;
		os << "FEATHER(validation" << i << ")=1" << endl;
		os << "FLY(validation" << i << ")=1" << endl;
		os << "BIRD(validation" << i << ")=1" << endl;
		os << "LAYEGGS(validation" << i << ")=1" << endl;
		os << "MEAT(validation" << i << ")=0" << endl;
		os << "CARNIVORE(validation" << i << ")=0" << endl;
		os << "POINTEDTEETH(validation" << i << ")=0" << endl;
		os << "CLAWS(validation" << i << ")=0" << endl;
		os << "FORWARDEYES(validation" << i << ")=0" << endl;
		os << "HOOFS(validation" << i << ")=0" << endl;
		os << "UNGULATE(validation" << i << ")=0" << endl;
		os << "EVENTOED(validation" << i << ")=0" << endl;
		os << "CUD(validation" << i << ")=0" << endl;
		os << "TAWNY(validation" << i << ")=0" << endl;
		os << "DARKSPOTS(validation" << i << ")=0" << endl;
		os << "BLACKSTRIPES(validation" << i << ")=0" << endl;
		os << "LONGLEGS(validation" << i << ")=0" << endl;
		os << "LONGNECK(validation" << i << ")=0" << endl;
		os << "WHITE(validation" << i << ")=0" << endl;
		os << "BLACK(validation" << i << ")=0" << endl;
		os << "SWIM(validation" << i << ")=0" << endl;
		os << "BLACKWHITE(validation" << i << ")=0" << endl;
		os << "GOODFLIER(validation" << i << ")=1" << endl;
		os << "ALBATROSS(validation" << i << ")=1" << endl;
		os << "CHEETAH(validation" << i << ")=0" << endl;
		os << "GIRAFFE(validation" << i << ")=0" << endl;
		os << "OSTRICH(validation" << i << ")=0" << endl;
		os << "PENGUIN(validation" << i << ")=0" << endl;
		os << "TIGER(validation" << i << ")=0" << endl;
		os << "ZEBRA(validation" << i << ")=0" << endl;
	}

	for(int i = fn3.size(); i < (2*fn3.size()); ++i)
	{
		os << "HAIR(validation" << i << ")=1" << endl;
		os << "MILK(validation" << i << ")=1" << endl;
		os << "MAMMAL(validation" << i << ")=1" << endl;
		os << "FEATHER(validation" << i << ")=0" << endl;
		os << "FLY(validation" << i << ")=0" << endl;
		os << "BIRD(validation" << i << ")=0" << endl;
		os << "LAYEGGS(validation" << i << ")=0" << endl;
		os << "MEAT(validation" << i << ")=1" << endl;
		os << "CARNIVORE(validation" << i << ")=1" << endl;
		os << "POINTEDTEETH(validation" << i << ")=1" << endl;
		os << "CLAWS(validation" << i << ")=1" << endl;
		os << "FORWARDEYES(validation" << i << ")=1" << endl;
		os << "HOOFS(validation" << i << ")=0" << endl;
		os << "UNGULATE(validation" << i << ")=0" << endl;
		os << "EVENTOED(validation" << i << ")=0" << endl;
		os << "CUD(validation" << i << ")=0" << endl;
		os << "TAWNY(validation" << i << ")=1" << endl;
		os << "DARKSPOTS(validation" << i << ")=1" << endl;
		os << "BLACKSTRIPES(validation" << i << ")=0" << endl;
		os << "LONGLEGS(validation" << i << ")=0" << endl;
		os << "LONGNECK(validation" << i << ")=0" << endl;
		os << "WHITE(validation" << i << ")=0" << endl;
		os << "BLACK(validation" << i << ")=0" << endl;
		os << "SWIM(validation" << i << ")=0" << endl;
		os << "BLACKWHITE(validation" << i << ")=0" << endl;
		os << "GOODFLIER(validation" << i << ")=0" << endl;
		os << "ALBATROSS(validation" << i << ")=0" << endl;
		os << "CHEETAH(validation" << i << ")=1" << endl;
		os << "GIRAFFE(validation" << i << ")=0" << endl;
		os << "OSTRICH(validation" << i << ")=0" << endl;
		os << "PENGUIN(validation" << i << ")=0" << endl;
		os << "TIGER(validation" << i << ")=0" << endl;
		os << "ZEBRA(validation" << i << ")=0" << endl;
	}

	for(int i = (2*fn3.size()); i < (3*fn3.size()); ++i)
	{
		os << "HAIR(validation" << i << ")=1" << endl;
		os << "MILK(validation" << i << ")=1" << endl;
		os << "MAMMAL(validation" << i << ")=1" << endl;
		os << "FEATHER(validation" << i << ")=0" << endl;
		os << "FLY(validation" << i << ")=0" << endl;
		os << "BIRD(validation" << i << ")=0" << endl;
		os << "LAYEGGS(validation" << i << ")=0" << endl;
		os << "MEAT(validation" << i << ")=0" << endl;
		os << "CARNIVORE(validation" << i << ")=0" << endl;
		os << "POINTEDTEETH(validation" << i << ")=0" << endl;
		os << "CLAWS(validation" << i << ")=0" << endl;
		os << "FORWARDEYES(validation" << i << ")=0" << endl;
		os << "HOOFS(validation" << i << ")=1" << endl;
		os << "UNGULATE(validation" << i << ")=1" << endl;
		os << "EVENTOED(validation" << i << ")=1" << endl;
		os << "CUD(validation" << i << ")=1" << endl;
		os << "TAWNY(validation" << i << ")=1" << endl;
		os << "DARKSPOTS(validation" << i << ")=1" << endl;
		os << "BLACKSTRIPES(validation" << i << ")=0" << endl;
		os << "LONGLEGS(validation" << i << ")=1" << endl;
		os << "LONGNECK(validation" << i << ")=1" << endl;
		os << "WHITE(validation" << i << ")=0" << endl;
		os << "BLACK(validation" << i << ")=0" << endl;
		os << "SWIM(validation" << i << ")=0" << endl;
		os << "BLACKWHITE(validation" << i << ")=0" << endl;
		os << "GOODFLIER(validation" << i << ")=0" << endl;
		os << "ALBATROSS(validation" << i << ")=0" << endl;
		os << "CHEETAH(validation" << i << ")=0" << endl;
		os << "GIRAFFE(validation" << i << ")=1" << endl;
		os << "OSTRICH(validation" << i << ")=0" << endl;
		os << "PENGUIN(validation" << i << ")=0" << endl;
		os << "TIGER(validation" << i << ")=0" << endl;
		os << "ZEBRA(validation" << i << ")=0" << endl;
	}

	for(int i = (3*fn3.size()); i < (4*fn3.size()); ++i)
	{
		os << "HAIR(validation" << i << ")=0" << endl;
		os << "MILK(validation" << i << ")=0" << endl;
		os << "MAMMAL(validation" << i << ")=0" << endl;
		os << "FEATHER(validation" << i << ")=1" << endl;
		os << "FLY(validation" << i << ")=0" << endl;
		os << "BIRD(validation" << i << ")=1" << endl;
		os << "LAYEGGS(validation" << i << ")=1" << endl;
		os << "MEAT(validation" << i << ")=0" << endl;
		os << "CARNIVORE(validation" << i << ")=0" << endl;
		os << "POINTEDTEETH(validation" << i << ")=0" << endl;
		os << "CLAWS(validation" << i << ")=0" << endl;
		os << "FORWARDEYES(validation" << i << ")=0" << endl;
		os << "HOOFS(validation" << i << ")=0" << endl;
		os << "UNGULATE(validation" << i << ")=0" << endl;
		os << "EVENTOED(validation" << i << ")=0" << endl;
		os << "CUD(validation" << i << ")=0" << endl;
		os << "TAWNY(validation" << i << ")=0" << endl;
		os << "DARKSPOTS(validation" << i << ")=0" << endl;
		os << "BLACKSTRIPES(validation" << i << ")=0" << endl;
		os << "LONGLEGS(validation" << i << ")=1" << endl;
		os << "LONGNECK(validation" << i << ")=1" << endl;
		os << "WHITE(validation" << i << ")=0" << endl;
		os << "BLACK(validation" << i << ")=0" << endl;
		os << "SWIM(validation" << i << ")=0" << endl;
		os << "BLACKWHITE(validation" << i << ")=0" << endl;
		os << "GOODFLIER(validation" << i << ")=0" << endl;
		os << "ALBATROSS(validation" << i << ")=0" << endl;
		os << "CHEETAH(validation" << i << ")=0" << endl;
		os << "GIRAFFE(validation" << i << ")=0" << endl;
		os << "OSTRICH(validation" << i << ")=1" << endl;
		os << "PENGUIN(validation" << i << ")=0" << endl;
		os << "TIGER(validation" << i << ")=0" << endl;
		os << "ZEBRA(validation" << i << ")=0" << endl;
	}

	for(int i = (4*fn3.size()); i < (5*fn3.size()); ++i)
	{
		os << "HAIR(validation" << i << ")=0" << endl;
		os << "MILK(validation" << i << ")=0" << endl;
		os << "MAMMAL(validation" << i << ")=0" << endl;
		os << "FEATHER(validation" << i << ")=1" << endl;
		os << "FLY(validation" << i << ")=1" << endl;
		os << "BIRD(validation" << i << ")=1" << endl;
		os << "LAYEGGS(validation" << i << ")=1" << endl;
		os << "MEAT(validation" << i << ")=0" << endl;
		os << "CARNIVORE(validation" << i << ")=0" << endl;
		os << "POINTEDTEETH(validation" << i << ")=0" << endl;
		os << "CLAWS(validation" << i << ")=0" << endl;
		os << "FORWARDEYES(validation" << i << ")=0" << endl;
		os << "HOOFS(validation" << i << ")=0" << endl;
		os << "UNGULATE(validation" << i << ")=0" << endl;
		os << "EVENTOED(validation" << i << ")=0" << endl;
		os << "CUD(validation" << i << ")=0" << endl;
		os << "TAWNY(validation" << i << ")=0" << endl;
		os << "DARKSPOTS(validation" << i << ")=0" << endl;
		os << "BLACKSTRIPES(validation" << i << ")=0" << endl;
		os << "LONGLEGS(validation" << i << ")=0" << endl;
		os << "LONGNECK(validation" << i << ")=0" << endl;
		os << "WHITE(validation" << i << ")=0" << endl;
		os << "BLACK(validation" << i << ")=0" << endl;
		os << "SWIM(validation" << i << ")=1" << endl;
		os << "BLACKWHITE(validation" << i << ")=1" << endl;
		os << "GOODFLIER(validation" << i << ")=0" << endl;
		os << "ALBATROSS(validation" << i << ")=0" << endl;
		os << "CHEETAH(validation" << i << ")=0" << endl;
		os << "GIRAFFE(validation" << i << ")=0" << endl;
		os << "OSTRICH(validation" << i << ")=0" << endl;
		os << "PENGUIN(validation" << i << ")=1" << endl;
		os << "TIGER(validation" << i << ")=0" << endl;
		os << "ZEBRA(validation" << i << ")=0" << endl;
	}

	for(int i = (5*fn3.size()); i < (6*fn3.size()); ++i)
	{
		os << "HAIR(validation" << i << ")=1" << endl;
		os << "MILK(validation" << i << ")=1" << endl;
		os << "MAMMAL(validation" << i << ")=1" << endl;
		os << "FEATHER(validation" << i << ")=0" << endl;
		os << "FLY(validation" << i << ")=0" << endl;
		os << "BIRD(validation" << i << ")=0" << endl;
		os << "LAYEGGS(validation" << i << ")=0" << endl;
		os << "MEAT(validation" << i << ")=1" << endl;
		os << "CARNIVORE(validation" << i << ")=1" << endl;
		os << "POINTEDTEETH(validation" << i << ")=1" << endl;
		os << "CLAWS(validation" << i << ")=1" << endl;
		os << "FORWARDEYES(validation" << i << ")=1" << endl;
		os << "HOOFS(validation" << i << ")=0" << endl;
		os << "UNGULATE(validation" << i << ")=0" << endl;
		os << "EVENTOED(validation" << i << ")=0" << endl;
		os << "CUD(validation" << i << ")=0" << endl;
		os << "TAWNY(validation" << i << ")=0" << endl;
		os << "DARKSPOTS(validation" << i << ")=0" << endl;
		os << "BLACKSTRIPES(validation" << i << ")=1" << endl;
		os << "LONGLEGS(validation" << i << ")=0" << endl;
		os << "LONGNECK(validation" << i << ")=0" << endl;
		os << "WHITE(validation" << i << ")=0" << endl;
		os << "BLACK(validation" << i << ")=0" << endl;
		os << "SWIM(validation" << i << ")=0" << endl;
		os << "BLACKWHITE(validation" << i << ")=0" << endl;
		os << "GOODFLIER(validation" << i << ")=0" << endl;
		os << "ALBATROSS(validation" << i << ")=0" << endl;
		os << "CHEETAH(validation" << i << ")=0" << endl;
		os << "GIRAFFE(validation" << i << ")=0" << endl;
		os << "OSTRICH(validation" << i << ")=0" << endl;
		os << "PENGUIN(validation" << i << ")=0" << endl;
		os << "TIGER(validation" << i << ")=1" << endl;
		os << "ZEBRA(validation" << i << ")=0" << endl;
	}

	for(int i = (6*fn3.size()); i < (7*fn3.size()); ++i)
	{
		os << "HAIR(validation" << i << ")=1" << endl;
		os << "MILK(validation" << i << ")=1" << endl;
		os << "MAMMAL(validation" << i << ")=1" << endl;
		os << "FEATHER(validation" << i << ")=0" << endl;
		os << "FLY(validation" << i << ")=0" << endl;
		os << "BIRD(validation" << i << ")=0" << endl;
		os << "LAYEGGS(validation" << i << ")=0" << endl;
		os << "MEAT(validation" << i << ")=0" << endl;
		os << "CARNIVORE(validation" << i << ")=0" << endl;
		os << "POINTEDTEETH(validation" << i << ")=0" << endl;
		os << "CLAWS(validation" << i << ")=0" << endl;
		os << "FORWARDEYES(validation" << i << ")=0" << endl;
		os << "HOOFS(validation" << i << ")=1" << endl;
		os << "UNGULATE(validation" << i << ")=1" << endl;
		os << "EVENTOED(validation" << i << ")=0" << endl;
		os << "CUD(validation" << i << ")=1" << endl;
		os << "TAWNY(validation" << i << ")=0" << endl;
		os << "DARKSPOTS(validation" << i << ")=0" << endl;
		os << "BLACKSTRIPES(validation" << i << ")=1" << endl;
		os << "LONGLEGS(validation" << i << ")=0" << endl;
		os << "LONGNECK(validation" << i << ")=0" << endl;
		os << "WHITE(validation" << i << ")=1" << endl;
		os << "BLACK(validation" << i << ")=0" << endl;
		os << "SWIM(validation" << i << ")=0" << endl;
		os << "BLACKWHITE(validation" << i << ")=0" << endl;
		os << "GOODFLIER(validation" << i << ")=0" << endl;
		os << "ALBATROSS(validation" << i << ")=0" << endl;
		os << "CHEETAH(validation" << i << ")=0" << endl;
		os << "GIRAFFE(validation" << i << ")=0" << endl;
		os << "OSTRICH(validation" << i << ")=0" << endl;
		os << "PENGUIN(validation" << i << ")=0" << endl;
		os << "TIGER(validation" << i << ")=0" << endl;
		os << "ZEBRA(validation" << i << ")=1" << endl;
	}

	os.close();
}
#endif
}







